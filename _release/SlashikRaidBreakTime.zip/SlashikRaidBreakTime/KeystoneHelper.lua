-- Shared keystone protocol used by DBM, BigWigs and this addon.
function createKeystoneHelper(openGuildKeys)
    local helper = {}
    local keyRoll = createKeystoneRollHelper()
    local libKeystone = LibStub("LibKeystone")
    local window
    local showAfterCombat = false
    local results = {}
    local nextRequestAt = 0
    local rosterSignature
    local refreshTimer

    local function cancelPendingRefresh()
        if refreshTimer then
            refreshTimer:Cancel()
            refreshTimer = nil
        end
    end

    local function fullName(unit)
        local name, realm = UnitFullName(unit)
        if not name then return nil end
        return name .. "-" .. ((realm and realm ~= "") and realm or GetNormalizedRealmName())
    end

    local function partyMembers()
        local members = { { unit = "player", name = fullName("player") } }
        if not IsInRaid() then
            for i = 1, GetNumSubgroupMembers() do
                local unit = "party" .. i
                local name = fullName(unit)
                if name then members[#members + 1] = { unit = unit, name = name } end
            end
        end
        return members
    end

    local function groupChannel()
        if IsInRaid() then return nil end
        if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
        if IsInGroup() then return "PARTY" end
    end

    local function updateRoster()
        local names, present = {}, {}
        for _, member in ipairs(partyMembers()) do
            if member.name then
                names[#names + 1] = member.name
                present[member.name] = true
            end
        end
        -- Unit order and leader changes do not change party membership.
        table.sort(names)
        local signature = (groupChannel() or "SOLO") .. ":" .. table.concat(names, ";")
        if signature == rosterSignature then return false end
        rosterSignature = signature
        keyRoll.cancel()
        -- Keep keys for remaining members while removing departed members' data.
        for name in pairs(results) do
            if not present[name] then results[name] = nil end
        end
        return true
    end

    local function scheduleRefresh()
        cancelPendingRefresh()
        refreshTimer = C_Timer.NewTimer(math.max(2, nextRequestAt - GetTime()), function()
            refreshTimer = nil
            if window and window:IsShown() then helper:refresh() end
        end)
    end

    local function ownKey()
        local mapID = C_MythicPlus.GetOwnedKeystoneChallengeMapID()
        local level = C_MythicPlus.GetOwnedKeystoneLevel()
        if mapID and level and mapID > 0 and level > 0 then return mapID, level end
        return 0, 0
    end

    local function render()
        if not window or not window.initialized or not window:IsShown() or InCombatLockdown() then return end
        local members = partyMembers()
        for i, row in ipairs(window.rows) do
            local member = members[i]
            local memberKey = member and results[member.name]
            row.teleport:SetShown(member ~= nil)
            updateDungeonTeleportButton(row.teleport, memberKey and memberKey.mapID)
            row.member = member
            row.post:SetShown(member ~= nil)
            row.post:Disable()
            row.go:SetShown(member ~= nil)
            row.go:Disable()
            row.name:SetText(member and member.name or "")
            -- Reset reused rows before applying the current party member's class color.
            row.name:SetTextColor(1, 1, 1)
            if member then
                local _, className = UnitClass(member.unit)
                local color = className and RAID_CLASS_COLORS[className]
                if color then
                    row.name:SetTextColor(color.r, color.g, color.b)
                end
            end
            local text = ""
            if member then
                local key = results[member.name]
                if not UnitIsConnected(member.unit) then
                    text = "Offline"
                elseif not key then
                    text = "Unknown"
                elseif key.mapID == 0 then
                    text = "No keystone"
                else
                    local dungeon = C_ChallengeMode.GetMapUIInfo(key.mapID)
                    text = string.format("+%d  %s", key.level, dungeon or ("Dungeon " .. key.mapID))
                    if dungeon then
                        row.post:Enable()
                        if IsInGroup() and not IsInRaid() then row.go:Enable() end
                    end
                end
            end
            row.key:SetText(text)
        end
        window.hint:SetText(IsInRaid() and "Party only — showing your own key." or "Sharing: SRBT, DBM & BigWigs.")
    end

    -- Only display current party members. LibKeystone shortens same-realm names,
    -- so resolve its callbacks back to the full names used by our rows.
    libKeystone.Register(helper, function(level, mapID, _, sender, channel)
        if channel ~= "PARTY" or IsInRaid() then return end
        if type(level) ~= "number" or type(mapID) ~= "number" then return end
        if level < 0 or level > 1000 or mapID < 0 or mapID > 100000 then return end
        if (mapID == 0) ~= (level == 0) then return end
        for _, member in ipairs(partyMembers()) do
            if member.name and (sender == member.name or sender == Ambiguate(member.name, "none")) then
                results[member.name] = { mapID = mapID, level = level }
                render()
                return
            end
        end
    end)

    function helper:refresh()
        if GetTime() < nextRequestAt then
            if not refreshTimer then scheduleRefresh() end
            return
        end
        cancelPendingRefresh()
        updateRoster()
        nextRequestAt = GetTime() + 2
        local mapID, level = ownKey()
        results[fullName("player")] = { mapID = mapID, level = level }
        render()
        -- LibKeystone handles requests, replies and network throttling itself.
        if not IsInRaid() then libKeystone.Request("PARTY") end
    end

    function helper:show()
        if InCombatLockdown() then
            showAfterCombat = true
            print("SlashikRaidBreakTime: The keystone window will open after combat.")
            return
        end
        if not window then
            window = CreateFrame("Frame", "SlashikRaidBreakTimeKeystoneFrame", UIParent, "BackdropTemplate")
            window:Hide()
            window:SetSize(868, 255)
            -- Secure spell buttons protect their parent: hide it safely during combat.
            RegisterStateDriver(window, "visibility", "[combat] hide;")
            window:SetClampedToScreen(true)
            local position = SlashikRaidBreakTimeDB and SlashikRaidBreakTimeDB.keystoneWindowPosition
            local anchors = { TOPLEFT = true, TOP = true, TOPRIGHT = true, LEFT = true,
                CENTER = true, RIGHT = true, BOTTOMLEFT = true, BOTTOM = true, BOTTOMRIGHT = true }
            if type(position) == "table" and anchors[position.point] and anchors[position.relativePoint]
                and type(position.x) == "number" and type(position.y) == "number" then
                window:SetPoint(position.point, UIParent, position.relativePoint, position.x, position.y)
            else
                window:SetPoint("CENTER")
            end
            window:SetFrameStrata("DIALOG")
            window:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark" })
            window:SetBackdropColor(0, 0, 0, 0.95)
            window:SetMovable(true)
            window:EnableMouse(true)
            window:RegisterForDrag("LeftButton")
            window:SetScript("OnDragStart", window.StartMoving)
            window:SetScript("OnDragStop", function(self)
                self:StopMovingOrSizing()
                local point, _, relativePoint, x, y = self:GetPoint()
                -- Store only serializable anchor values, not the parent frame itself.
                SlashikRaidBreakTimeDB = SlashikRaidBreakTimeDB or {}
                SlashikRaidBreakTimeDB.keystoneWindowPosition = {
                    point = point, relativePoint = relativePoint, x = x, y = y,
                }
            end)
            window:SetScript("OnHide", cancelPendingRefresh)
            table.insert(UISpecialFrames, "SlashikRaidBreakTimeKeystoneFrame")
            local title = window:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
            title:SetPoint("TOPLEFT", 18, -18)
            title:SetText("Party Keystones")
            local guildKeys = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
            guildKeys:SetSize(100, 24)
            -- Anchor to the frame, keeping clear of secure buttons' anchor chains.
            guildKeys:SetPoint("TOPLEFT", 18 + title:GetStringWidth() + 16, -15)
            guildKeys:SetText("Guild Keys")
            guildKeys:SetScript("OnClick", function()
                if openGuildKeys then openGuildKeys() end
            end)
            local close = CreateFrame("Button", nil, window, "UIPanelCloseButton")
            close:SetPoint("TOPRIGHT", -4, -4)
            window.rows = {}
            for i = 1, 5 do
                local row = {}
                row.name = window:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
                row.name:SetPoint("TOPLEFT", 18, -52 - (i - 1) * 28)
                row.name:SetSize(240, 24)
                row.name:SetJustifyH("LEFT")
                row.key = window:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
                row.key:SetPoint("TOPLEFT", 270, -52 - (i - 1) * 28)
                row.key:SetSize(200, 24)
                row.key:SetJustifyH("LEFT")
                row.post = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
                row.post:SetSize(90, 22)
                row.post:SetPoint("LEFT", row.key, "RIGHT", 8, 0)
                row.post:SetText("Guild Post")
                row.post:SetScript("OnClick", function()
                    -- Resolve the current row again so roster changes cannot post an old key.
                    local member = row.member
                    if not member or fullName(member.unit) ~= member.name or not UnitIsConnected(member.unit) then return end
                    local key = results[member.name]
                    if key then postKeystoneToGuild(key.mapID, key.level) end
                end)
                row.go = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
                row.go:SetSize(74, 22)
                row.go:SetPoint("LEFT", row.post, "RIGHT", 6, 0)
                row.go:SetText("Let's Go")
                row.go:SetScript("OnClick", function()
                    if keyRoll:isPending() then return end
                    local member = row.member
                    if not member or fullName(member.unit) ~= member.name then return end
                    local key = results[member.name]
                    if key then announceKeystoneToParty(member.name, key.mapID, key.level) end
                end)
                row.teleport = createDungeonTeleportButton(window, i)
                window.rows[i] = row
            end
            window.hint = window:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            window.hint:SetPoint("BOTTOMLEFT", 18, 26)
            window.hint:SetSize(250, 14)
            window.hint:SetJustifyV("MIDDLE")
            window.hint:SetJustifyH("LEFT")
            local refresh = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
            refresh:SetSize(100, 26)
            refresh:SetPoint("BOTTOMRIGHT", -18, 20)
            refresh:SetText("Refresh")
            refresh:SetScript("OnClick", function() helper:refresh() end)

            local roll = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
            roll:SetSize(100, 26)
            roll:SetPoint("RIGHT", refresh, "LEFT", -8, 0)
            roll:SetText("Roll")
            roll:SetScript("OnClick", function()
                if not IsInGroup() or IsInRaid() then
                    print("SlashikRaidBreakTime: Join a party to roll for the next key.")
                    return
                end
                local keys = {}
                if not canAnnounceKeystoneToParty() then
                    print("SlashikRaidBreakTime: Please wait a few seconds before rolling another key.")
                    return
                end
                for _, member in ipairs(partyMembers()) do
                    local key = results[member.name]
                    if key and key.mapID > 0 and key.level > 0 and UnitIsConnected(member.unit)
                        and C_ChallengeMode.GetMapUIInfo(key.mapID) then
                        keys[#keys + 1] = { owner = member.name, unit = member.unit, mapID = key.mapID, level = key.level }
                    end
                end
                keyRoll:start(keys, function(chosen)
                    local current = results[chosen.owner]
                    if fullName(chosen.unit) ~= chosen.owner or not current
                        or current.mapID ~= chosen.mapID or current.level ~= chosen.level then
                        print("SlashikRaidBreakTime: The selected key changed. Refresh and roll again.")
                        return
                    end
                    announceKeystoneToParty(chosen.owner, chosen.mapID, chosen.level)
                end)
            end)

            window.autoOpen = CreateFrame("CheckButton", nil, window, "UICheckButtonTemplate")
            window.autoOpen:SetSize(24, 24)
            window.autoOpen:SetPoint("RIGHT", roll, "LEFT", -210, 0)
            local autoOpenLabel = window:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            autoOpenLabel:SetPoint("LEFT", window.autoOpen, "RIGHT", 2, 0)
            autoOpenLabel:SetText("Open when Mythic+ finishes")
            window.autoOpen:SetScript("OnClick", function(self)
                -- Keep this window preference separate from the break-timer settings.
                SlashikRaidBreakTimeDB = SlashikRaidBreakTimeDB or {}
                SlashikRaidBreakTimeDB.autoOpenKeystones = self:GetChecked() == true
            end)

            -- Keep the decorative keystone in its own column above Refresh.
            window.keystoneArt = window:CreateTexture(nil, "ARTWORK")
            window.keystoneArt:SetSize(96, 96)
            window.keystoneArt:SetPoint("BOTTOM", refresh, "TOP", 0, 12)
            window.keystoneArt:SetTexture("Interface\\AddOns\\SlashikRaidBreakTime\\keystoneIcon.tga")

            window.keystoneCaption = window:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            local fontPath, fontSize, fontFlags = window.keystoneCaption:GetFont()
            window.keystoneCaption:SetFont(fontPath, fontSize * 2, fontFlags)
            window.keystoneCaption:SetPoint("BOTTOM", window.keystoneArt, "TOP", 0, 6)
            window.keystoneCaption:SetWidth(100)
            window.keystoneCaption:SetJustifyH("CENTER")
            window.keystoneCaption:SetText("Never stop pushing!")
            window.initialized = true
        end
        window.autoOpen:SetChecked(SlashikRaidBreakTimeDB and SlashikRaidBreakTimeDB.autoOpenKeystones == true)
        window:Show()
        self:refresh()
        render()
    end

    local events = CreateFrame("Frame")
    events:RegisterEvent("PLAYER_LOGIN")
    events:RegisterEvent("GROUP_ROSTER_UPDATE")
    events:RegisterEvent("BAG_UPDATE_DELAYED")
    events:RegisterEvent("CHALLENGE_MODE_COMPLETED")
    events:RegisterEvent("PLAYER_REGEN_ENABLED")
    events:RegisterEvent("SPELLS_CHANGED")
    events:RegisterEvent("SPELL_UPDATE_COOLDOWN")
    events:SetScript("OnEvent", function(_, event)
        if event == "PLAYER_LOGIN" then
            updateRoster()
        elseif event == "PLAYER_REGEN_ENABLED" then
            if showAfterCombat then
                showAfterCombat = false
                helper:show()
            else
                render()
            end
        elseif event == "SPELLS_CHANGED" or event == "SPELL_UPDATE_COOLDOWN" then
            render()
        elseif event == "CHALLENGE_MODE_COMPLETED" then
            if SlashikRaidBreakTimeDB and SlashikRaidBreakTimeDB.autoOpenKeystones == true then
                helper:show()
            end
        elseif event == "GROUP_ROSTER_UPDATE" then
            local changed = updateRoster()
            if changed and window and window:IsShown() then
                scheduleRefresh()
            end
            render()
        elseif event == "BAG_UPDATE_DELAYED" then
            local mapID, level = ownKey()
            results[fullName("player")] = { mapID = mapID, level = level }
            render()
        end
    end)

    return helper
end
