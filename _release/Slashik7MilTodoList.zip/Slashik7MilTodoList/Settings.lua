local _, addon = ...

addon.defaults = { showOnLogin = false, lockWindow = false }
addon.tasks = {
  { id = "abundance", label = "Abundance\n20,000 points" },
  { id = "haranir", label = "Legends of\nthe Haranir" },
  { id = "liadrin", label = "Lady Liadrin’s\nApex Cache #1" },
  { id = "assignment1", label = "Special\nAssignment #1" },
  { id = "assignment2", label = "Special\nAssignment #2" },
  { id = "assignment3", label = "Special Assignment #3\n(Coiled Isle)" },
}

function addon:InitializeDatabase()
  if type(Slashik7MilTodoListDB) ~= "table" then Slashik7MilTodoListDB = {} end
  self.db = Slashik7MilTodoListDB
  local db = self.db
  db.settings = db.settings or {}
  db.characters = db.characters or {}
  db.order = db.order or {}
  db.version = 1
  if (db.automationVersion or 0) < 2 then
    -- Version 1.6 used historical quest flags that can survive a weekly reset.
    -- Clear that unreliable snapshot once; future automatic checks come from turn-ins.
    for _, character in pairs(db.characters) do
      character.completed = character.completed or {}
      for _, task in ipairs(self.tasks) do character.completed[task.id] = nil end
      character.automaticAssignments = {}
    end
    db.automationVersion = 2
  end
  for key, value in pairs(self.defaults) do
    if db.settings[key] == nil then db.settings[key] = value end
  end
end
